const view = document.getElementById("view");
const storeKey = "emotiekompas-demo-v1";
let state = load();
let installPrompt = null;

function load(){try{return JSON.parse(localStorage.getItem(storeKey))||{};}catch{return {};}}
function save(){try{localStorage.setItem(storeKey,JSON.stringify(state));}catch(e){alert("Opslaan lukt niet in deze browser.");}}
function esc(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function field(key,label,placeholder=""){return `<label for="${key}">${label}</label><textarea id="${key}" data-field="${key}" placeholder="${placeholder}">${esc(state[key]||"")}</textarea>`;}
function bindFields(){document.querySelectorAll("[data-field]").forEach(el=>el.addEventListener("input",()=>{state[el.dataset.field]=el.value;save();}));}
function button(label,action,alt=false){return `<button class="action ${alt?"alt":""}" data-action="${action}">${label}</button>`;}
function go(page){const pages={
home:`<h2>Welkom bij EmotieKompas</h2><p>Kies een onderdeel. Jij bepaalt wat je invult en wat je deelt.</p>`,
checkin:`<h2>🌡️ Hoe gaat het nu met je?</h2><p>Kies een gevoel en geef aan hoeveel spanning je ervaart.</p>
<div class="choice-grid">${["😌 Rustig","🙂 Blij","😢 Verdrietig","😡 Boos","😟 Bang","😣 Gestrest","😤 Gefrustreerd","😵 Overprikkeld","😶 Leeg","😕 Onzeker"].map(x=>`<button class="choice" data-feeling="${x}" aria-pressed="${state.feeling===x}">${x}</button>`).join("")}</div>
<label for="intensity">Spanning: <strong id="intensityValue">${state.intensity??4}/10</strong></label><input id="intensity" type="range" min="0" max="10" value="${state.intensity??4}">
<div class="callout" id="levelText">${levelText(state.intensity??4)}</div>${button("Verder naar triggers","triggers")}`,
emotions:`<h2>🌈 Emoties begrijpen</h2><p>Een emotie is niet goed of fout. Je kunt onderzoeken wat het gevoel je probeert te vertellen.</p>
${field("emotionMeaning","Wat zou deze emotie nodig kunnen hebben?","Bijvoorbeeld rust, contact, duidelijkheid of een grens aangeven.")}
<div class="callout">Je mag voelen wat je voelt. Je kunt tegelijk oefenen met een reactie die veilig is voor jou en anderen.</div>`,
triggers:`<h2>🔎 Triggers en signalen</h2><p>Je hoeft niets te delen waar je niet klaar voor bent. Je kunt ook alleen de signalen herkennen.</p>
${field("trigger","Wat gebeurde er vlak voordat je gevoel veranderde?","Een situatie, geluid, gedachte, verandering of contactmoment...")}
${field("body","Wat merkte je in je lichaam?","Bijvoorbeeld gespannen spieren, onrust, stilvallen...")}
${field("thoughts","Welke gedachten kwamen op?","Wat zei je tegen jezelf?")}
${field("urge","Wat had je op dat moment nodig of wilde je doen?","Beschrijf je behoefte of impuls.")}
${button("Bekijk oefeningen","tools")}`,
tools:`<h2>🧰 Mijn gereedschapskist</h2><p>Kies één oefening. Als iets niet prettig voelt, stop dan en kies iets anders.</p>
<div class="choice-grid">${["👣 Gronden","🌬️ Ademruimte","👀 Zintuigen","🚶 Bewegen","🎵 Muziek","🖍️ Tekenen of schrijven","🔕 Prikkels verminderen","💬 Contact zoeken"].map(x=>`<button class="choice" data-tool="${x}" aria-pressed="${state.tool===x}">${x}</button>`).join("")}</div>
<div class="callout" id="toolText">${state.tool?toolText(state.tool):"Kies hierboven een oefening om de uitleg te zien."}</div>
${field("toolReflection","Wat werkte voor jou?","Wat merkte je tijdens of na de oefening?")}`,
plan:`<h2>📋 Mijn signaleringsplan</h2><p>Vul dit bij voorkeur samen in met een begeleider die je vertrouwt.</p>
<div class="zone green"><h3>🟢 Groen – Ik voel me oké</h3>${field("green","Hoe merk ik dat het goed gaat? Wat helpt om dit vast te houden?","Mijn signalen, routines en fijne activiteiten...")}</div>
<div class="zone orange"><h3>🟠 Oranje – Mijn spanning loopt op</h3>${field("orange","Wat zijn mijn vroege signalen? Wat helpt?","Mijn triggers, lichaamssignalen en helpende acties...")}</div>
<div class="zone red"><h3>🔴 Rood – Het is me te veel</h3>${field("red","Wat heb ik nodig om veilig te blijven? Wat moet mijn omgeving doen of juist laten?","Afspraken, steun en wat liever niet helpt...")}</div>
<div class="zone blue"><h3>🔵 Herstel – Ik kom weer bij</h3>${field("recovery","Wat helpt na een moeilijk moment?","Rust, contact, tijd en een passende nabespreking...")}</div>
${button("Print / bewaar als PDF","print",true)}`,
support:`<h2>🤝 Mijn steunnetwerk</h2><p>Wie kan jou helpen als het moeilijk wordt?</p>
${field("supportPerson","Vertrouwde steunpersonen (naam of rol)","Bijvoorbeeld mentor, begeleider of familielid. Gebruik in deze demo liever geen volledige namen.")}
${field("supportNeed","Hoe wil ik geholpen worden?","Bijvoorbeeld rustig praten, even naast me zitten of niet te veel vragen stellen.")}
<div class="callout"><strong>Een hulpzin:</strong><br>“Ik vind het lastig om uit te leggen, maar ik heb nu steun nodig. Kun je even bij me blijven?”</div>`,
reflection:`<h2>🌱 Terugblik</h2><p>Reflecteren is niet beoordelen. Je ontdekt wat jou kan helpen.</p>
${field("reflection","Wat heb ik ontdekt? Wat werkte een beetje?","Een klein inzicht telt ook.")}
<label for="afterLevel">Hoe is je spanning nu? <strong id="afterValue">${state.afterLevel??4}/10</strong></label><input id="afterLevel" type="range" min="0" max="10" value="${state.afterLevel??4}">`,
guide:`<h2>👥 Begeleidersmodus</h2><p>Gebruik dit onderdeel als gesprekssteun. De jongere blijft eigenaar van de eigen gevoelens en keuzes.</p>
<div class="callout"><strong>Gespreksopbouw</strong><ol><li>Eerst verbinding en veiligheid bieden.</li><li>De emotie erkennen, niet beoordelen.</li><li>Vragen naar vroege signalen en behoeften.</li><li>Keuzes aanbieden binnen de veiligheidsafspraken.</li><li>Op een passend moment samen terugblikken.</li></ol></div>
${field("guideNotes","Reflectie begeleider (zonder persoonsgegevens)","Wat benoemde de jongere zelf? Wat was helpend in mijn houding?")}
${field("guideAction","Gezamenlijke afspraak","Welke kleine afspraak is gemaakt? Wie doet wat?")}
<p class="muted">Volg altijd de professionele richtlijnen, het teambeleid en het individuele veiligheidsplan. Noteer noodzakelijke verslaglegging in het officiële dossier, niet in deze demo.</p>`
};
view.innerHTML=pages[page]||pages.home;
bindFields();
document.querySelectorAll("[data-feeling]").forEach(b=>b.addEventListener("click",()=>{state.feeling=b.dataset.feeling;save();go("checkin");}));
document.querySelectorAll("[data-tool]").forEach(b=>b.addEventListener("click",()=>{state.tool=b.dataset.tool;save();go("tools");}));
const range=document.getElementById("intensity");
if(range)range.addEventListener("input",()=>{state.intensity=+range.value;document.getElementById("intensityValue").textContent=range.value+"/10";document.getElementById("levelText").textContent=levelText(+range.value);save();});
const after=document.getElementById("afterLevel");
if(after)after.addEventListener("input",()=>{state.afterLevel=+after.value;document.getElementById("afterValue").textContent=after.value+"/10";save();});
document.querySelectorAll("[data-action]").forEach(b=>b.addEventListener("click",()=>{if(b.dataset.action==="print")window.print();else go(b.dataset.action);}));
window.scrollTo({top:document.querySelector("main").offsetTop,behavior:"smooth"});
}
function levelText(n){return n<=3?"🟢 Je ervaart weinig spanning. Wat helpt om dit zo te houden?":n<=6?"🟠 Je spanning is merkbaar. Misschien helpt het om ruimte te maken.":"🔴 Het voelt intens. Richt je eerst op rust, veiligheid en steun.";}
function toolText(t){const map={
"👣 Gronden":"Voel je voeten op de vloer. Merk de steun van je stoel op. Kijk rustig om je heen en benoem waar je bent.",
"🌬️ Ademruimte":"Laat je adem vanzelf gaan. Merk de in- en uitademing op zonder deze te forceren. Als dit niet prettig voelt, richt je aandacht op je voeten.",
"👀 Zintuigen":"Benoem enkele dingen die je ziet en hoort. Raak iets met een vertrouwde textuur aan als dat prettig is.",
"🚶 Bewegen":"Maak een rustige wandeling of rek je even uit. Kies iets dat comfortabel voelt.",
"🎵 Muziek":"Kies muziek die past bij wat je nodig hebt. Zet het volume op een prettig niveau.",
"🖍️ Tekenen of schrijven":"Teken hoe je gevoel eruitziet of schrijf losse woorden op. Je hoeft het niet te delen.",
"🔕 Prikkels verminderen":"Kijk of minder geluid, zachter licht of een rustige plek prettig is. Bespreek wat veilig en haalbaar is.",
"💬 Contact zoeken":"Vraag iemand die je vertrouwt of die even bij je kan zijn. Je hoeft niet meteen alles te vertellen."
};return map[t]||"";}
document.addEventListener("click",e=>{const p=e.target.closest("[data-page]");if(p){e.preventDefault();go(p.dataset.page);}});
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();installPrompt=e;document.getElementById("installBtn").hidden=false;});
document.getElementById("installBtn").addEventListener("click",async()=>{if(!installPrompt)return;installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;document.getElementById("installBtn").hidden=true;});
go("home");
