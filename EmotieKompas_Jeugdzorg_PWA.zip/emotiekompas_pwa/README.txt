EMOTIEKOMPAS – JEUGDZORG PWA
============================

INHOUD
- index.html       startpagina
- styles.css       vormgeving
- app.js           interactieve onderdelen
- manifest.webmanifest  installatiegegevens
- sw.js            offline cache
- icons/           app-iconen

ZO ZET JE DE APP GRATIS ONLINE MET GITHUB PAGES
1. Maak gratis een account op https://github.com/
2. Maak een nieuwe repository aan, bijvoorbeeld: emotiekompas.
3. Pak het ZIP-bestand uit op je computer.
4. Upload alle bestanden en de map 'icons' naar de hoofdmap van de repository.
   Let op: index.html moet direct in de hoofdmap staan, niet in een extra submap.
5. Ga in GitHub naar Settings > Pages.
6. Kies bij Build and deployment: Deploy from a branch.
7. Kies branch 'main' en map '/ (root)' en klik Save.
8. Wacht even. GitHub toont daarna de website-link, meestal:
   https://JOUW-GITHUB-NAAM.github.io/emotiekompas/
9. Open die link op je Android-telefoon in Chrome.
10. Kies in Chrome het menu (⋮) > 'App installeren' of 'Toevoegen aan startscherm'.

ALTERNATIEF
Je kunt dezelfde bestanden uploaden naar een statische hostingdienst zoals Netlify.
Gebruik altijd de HTTPS-link om installatie en offline functionaliteit mogelijk te maken.

BELANGRIJK OVER PRIVACY EN VEILIGHEID
- Dit is een demonstratie/prototype, geen gecertificeerd zorgproduct.
- De app bewaart ingevulde gegevens in localStorage van de browser op het apparaat.
- Gegevens kunnen verloren gaan bij browsergegevens wissen, apparaatwissel of gebruik van een andere browser.
- Er is geen login, versleutelde synchronisatie, rollenbeheer of centrale back-up.
- Gebruik deze versie NIET met echte namen, geboortedata, contactgegevens, dossiers,
  trauma-informatie of andere herleidbare cliëntgegevens.
- Gebruik hem niet als formeel cliëntdossier of als enige veiligheidsplan.
- Voor professioneel gebruik met jongeren zijn een privacy- en securitytoets,
  passende AVG-grondslag, beveiligde opslag, toegangsbeheer, bewaartermijnen,
  afspraken met de organisatie en toetsing van de inhoud nodig.
- Bij acute onveiligheid: volg de bestaande professionele veiligheidsprotocollen.

AANPASSEN
Je kunt teksten en kleuren wijzigen in app.js en styles.css.
Na wijzigingen moet je de bestanden opnieuw uploaden naar GitHub.
